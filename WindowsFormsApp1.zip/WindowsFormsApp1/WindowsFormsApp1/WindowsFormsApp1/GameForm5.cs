﻿using System;
using System.Drawing;
using System.Media;
using System.Windows.Forms;



namespace WindowsFormsApp1
{
    public partial class GameForm : Form 
    {
        static Random random = new Random();
        static int indx = random.Next(0, 199);
        static string word;
        static string hint;
        static Letters letterCard1 = new Letters();
        static Letters letterCard2 = new Letters();
        static Letters letterCard3 = new Letters();
        static Letters letterCard4 = new Letters();
        static Letters letterCard5 = new Letters();
        private SoundPlayer soundplayer;
        static int awardCount = 0;


        public GameForm()
        {
            /*TODO: 
                    Sounds per letter name on hover
                    drag animation
            */
            InitializeComponent();
            SubmitButton.Visible = false;
            NextButton.Visible = false;
            hintBox.Visible = false;
            hintButton.Visible = false;
        }

        private void StartButton_Click(object sender, EventArgs e)
        {


            // Card shuffle audio
            soundplayer = new SoundPlayer("CardShuffle02.wav");
            soundplayer.Play();
            StartButton.Text = "Restart";
            // reset all feilds - restarts game in in progress
            hintBox.Visible = false;
            hintButton.Visible = true;
            awardCount = 0;
            awardTextBox.Text = awardCount.ToString();
            SubmitButton.Visible = true;
            NextButton.Visible = true;
            placeBox1.Image = null;
            placeBox2.Image = null;
            placeBox3.Image = null;
            placeBox4.Image = null;
            placeBox5.Image = null;

            indx = random.Next(0, 199);
            word = Words5L.WordList(indx);
            hint = Words5L.HintList(indx);



            char[] charArray = word.ToCharArray();
            Array.Sort<char>(charArray);
                        
            char letterID1 = charArray[0];
            letterCard1 = Letters.List(letterID1);
            pictureBox1.Image = letterCard1.LetterImage;
                        
            char letterID2 = charArray[1];
            letterCard2 = Letters.List(letterID2);
            pictureBox2.Image = letterCard2.LetterImage;
                        
            char letterID3 = charArray[2];
            letterCard3 = Letters.List(letterID3);
            pictureBox3.Image = letterCard3.LetterImage;

            char letterID4 = charArray[3];
            letterCard4 = Letters.List(letterID4);
            pictureBox4.Image = letterCard4.LetterImage;

            char letterID5 = charArray[4];
            letterCard5 = Letters.List(letterID5);
            pictureBox5.Image = letterCard5.LetterImage;

            
        }


        private void SubmitButton_Click(object sender, EventArgs e)
        {
            
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            char[] submitArray = word.ToCharArray();
                char submitID1 = submitArray[0];
                Letters submitCard1 = Letters.List(submitID1);
                char submitID2 = submitArray[1];
                Letters submitCard2 = Letters.List(submitID2);
                char submitID3 = submitArray[2];
                Letters submitCard3 = Letters.List(submitID3);
                char submitID4 = submitArray[3];
                Letters submitCard4 = Letters.List(submitID4);
                char submitID5 = submitArray[4];
                Letters submitCard5 = Letters.List(submitID5);

                if (placeBox1.Image == submitCard1.LetterImage && placeBox2.Image == submitCard2.LetterImage && placeBox3.Image == submitCard3.LetterImage && placeBox4.Image == submitCard4.LetterImage && placeBox5.Image == submitCard5.LetterImage)
                {
                soundplayer = new SoundPlayer("Cheer.wav");
                soundplayer.Play();
                textBox1.Text = "Congratulations! The word was: " + word + "! CORRECT!";
                hintBox.Visible = true;
                hintBox.Text = "Please select Next";
                awardCount += 1;
                awardTextBox.Text = awardCount.ToString();
                SubmitButton.Visible = false;
                hintButton.Visible = false;
            }
            else
            {
                soundplayer = new SoundPlayer("female_ohh_suprised.wav");
                soundplayer.Play();
                textBox1.Text = "OH NO! Please try again!";
                hintBox.Visible = true;
                hintBox.Text = "Hint: " + hint;
                hintButton.Visible = true;
            }
                
        }

        private void NextButton_Click(object sender, EventArgs e)
        {
            SubmitButton.Visible = true;
            hintBox.Visible = false;
            hintButton.Visible = true;
            // play card shuffle audio
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            // sounds conflict
            soundplayer = new SoundPlayer("CardShuffle02.wav");
            soundplayer.Play();

            placeBox1.Image = null;
            placeBox2.Image = null;
            placeBox3.Image = null;
            placeBox4.Image = null;
            placeBox5.Image = null;
            textBox1.Text = null;

            Random random = new Random();

            int indx = random.Next(0, 199);
            word = Words5L.WordList(indx);
            hint = Words5L.HintList(indx);



            char[] charArray = word.ToCharArray();
            Array.Sort<char>(charArray);


            char letterID1 = charArray[0];
            letterCard1 = Letters.List(letterID1);
            pictureBox1.Image = letterCard1.LetterImage;


            char letterID2 = charArray[1];
            letterCard2 = Letters.List(letterID2);
            pictureBox2.Image = letterCard2.LetterImage;


            char letterID3 = charArray[2];
            letterCard3 = Letters.List(letterID3);
            pictureBox3.Image = letterCard3.LetterImage;

            char letterID4 = charArray[3];
            letterCard4 = Letters.List(letterID4);
            pictureBox4.Image = letterCard4.LetterImage;

            char letterID5 = charArray[4];
            letterCard5 = Letters.List(letterID5);
            pictureBox5.Image = letterCard5.LetterImage;
        }
 
        
        
        private void Exit_Game_Button_Click(object sender, EventArgs e)
        {
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            
            this.Close();
        }

        private void GameForm_Load(object sender, EventArgs e)
        {
            placeBox1.AllowDrop = true;
            placeBox2.AllowDrop = true;
            placeBox3.AllowDrop = true;
            placeBox4.AllowDrop = true;
            placeBox5.AllowDrop = true;
        }

        

        private void placeBox1_Click(object sender, EventArgs e)
        {

        }

        private void placeBox2_Click(object sender, EventArgs e)
        {

        }

        private void placeBox3_Click(object sender, EventArgs e)
        {

        }

        private void placeBox4_Click(object sender, EventArgs e)
        {

        }

        private void placeBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_DragDrop(object sender, DragEventArgs e)
        {
           
        }

        private void pictureBox2_DragDrop(object sender, DragEventArgs e)
        {

        }

        private void pictureBox3_DragDrop(object sender, DragEventArgs e)
        {

        }

        private void pictureBox4_DragDrop(object sender, DragEventArgs e)
        {

        }

        private void pictureBox5_DragDrop(object sender, DragEventArgs e)
        {

        }

        //On mouseclick of PictureBox1
        
        private void PictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            Cursor.Current = Cursors.NoMove2D;
            var img = pictureBox1.Image;
            //copies image in picture box while holding down mouse
            DoDragDrop(img, DragDropEffects.Copy);
            if (img == null) return;
        }

        private void PictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            Cursor.Current = Cursors.NoMove2D;
            var img = pictureBox2.Image;
            //copies image in picture box while holding down mouse
            DoDragDrop(img, DragDropEffects.Copy);
            if (img == null) return;
        }
        
        private void PictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            Cursor.Current = Cursors.NoMove2D;
            var img = pictureBox3.Image;
            //copies image in picture box while holding down mouse
            DoDragDrop(img, DragDropEffects.Copy);
            if (img == null) return;
        }

        private void PictureBox4_MouseDown(object sender, MouseEventArgs e)
        {
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            Cursor.Current = Cursors.NoMove2D;
            var img = pictureBox4.Image;
            //copies image in picture box while holding down mouse
            DoDragDrop(img, DragDropEffects.Copy);
            if (img == null) return;
        }

        private void PictureBox5_MouseDown(object sender, MouseEventArgs e)
        {
            
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            Cursor.Current = Cursors.NoMove2D;
            var img = pictureBox5.Image;
            //copies image in picture box while holding down mouse
            DoDragDrop(img, DragDropEffects.Copy);
            if (img == null) return;
        }

        private void PlaceBox1_DragEnter(object sender, DragEventArgs e)
        {
            
            // See if this is a copy and the data includes an image.
            if (e.Data.GetDataPresent(DataFormats.Bitmap) &&
                (e.AllowedEffect & DragDropEffects.Copy) != 0)
            {
                // Allow this.
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                // Don't allow any other drop.
                e.Effect = DragDropEffects.None;
            }
        }

        //accepts the drop
        private void PlaceBox1_DragDrop(object sender, DragEventArgs e)
        {
            {
                placeBox1.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap, true);
            }
        }

        private void PlaceBox2_DragEnter(object sender, DragEventArgs e)
        {
            // See if this is a copy and the data includes an image.
            if (e.Data.GetDataPresent(DataFormats.Bitmap) &&
                (e.AllowedEffect & DragDropEffects.Copy) != 0)
            {
                // Allow this.
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                // Don't allow any other drop.
                e.Effect = DragDropEffects.None;
            }
        }

        //accepts the drop
        private void PlaceBox2_DragDrop(object sender, DragEventArgs e)
        {
            {
                placeBox2.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap, true);
            }
        }

        private void PlaceBox3_DragEnter(object sender, DragEventArgs e)
        {
            // See if this is a copy and the data includes an image.
            if (e.Data.GetDataPresent(DataFormats.Bitmap) &&
                (e.AllowedEffect & DragDropEffects.Copy) != 0)
            {
                // Allow this.
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                // Don't allow any other drop.
                e.Effect = DragDropEffects.None;
            }
        }

        //accepts the drop
        private void PlaceBox3_DragDrop(object sender, DragEventArgs e)
        {
            {
                placeBox3.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap, true);
            }
        }

        private void PlaceBox4_DragEnter(object sender, DragEventArgs e)
        {
            // See if this is a copy and the data includes an image.
            if (e.Data.GetDataPresent(DataFormats.Bitmap) &&
                (e.AllowedEffect & DragDropEffects.Copy) != 0)
            {
                // Allow this.
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                // Don't allow any other drop.
                e.Effect = DragDropEffects.None;
            }
        }

        //accepts the drop
        private void PlaceBox4_DragDrop(object sender, DragEventArgs e)
        {
            {
                placeBox4.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap, true);
            }
        }

        private void PlaceBox5_DragEnter(object sender, DragEventArgs e)
        {
            // See if this is a copy and the data includes an image.
            if (e.Data.GetDataPresent(DataFormats.Bitmap) &&
                (e.AllowedEffect & DragDropEffects.Copy) != 0)
            {
                // Allow this.
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                // Don't allow any other drop.
                e.Effect = DragDropEffects.None;
            }
        }

        //accepts the drop
        private void PlaceBox5_DragDrop(object sender, DragEventArgs e)
        {
            {
                placeBox5.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap, true);
            }
        }

        private void hintBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void awardTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void hintButton_Click(object sender, EventArgs e)
        {
            if(hintBox.Visible == true)
            {
                hintBox.Visible = false;
            }
            else
            {
                hintBox.Visible = true;
                hintBox.Text = "Hint: " + hint;
            }
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
