﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class SpellingGame
    {
        /// <summary>
        /// The main entry point for the application.
        /// opens the Intro form to select play or exit
        /// </summary>
        
        [STAThread]
        static void Main()
        {
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new IntroForm());
           
        }
    

    }
}
