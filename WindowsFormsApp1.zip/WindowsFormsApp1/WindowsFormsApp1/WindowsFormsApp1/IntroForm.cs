﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.Threading;


namespace WindowsFormsApp1
{
    public partial class IntroForm : Form
    {
        private SoundPlayer soundplayer;
        private SoundPlayer _soundplayer;

        public IntroForm()
        {
            InitializeComponent();
            
            _soundplayer = new SoundPlayer("bensound-summer.wav");
            _soundplayer.PlayLooping();
            
            
        }
    // intro form opens the GameForm
    private void StartButton_Click(object sender, EventArgs e)
        {
            
            StartButton.Visible = false;
            ExitButton.Visible = false;
            play3Button.Visible = true;
            play4Button.Visible = true;
            play5Button.Visible = true;
            play6Button.Visible = true;
            backButton.Visible = true;
            
        }

        void GameForm_FormClosed(object sender, FormClosedEventArgs e)
        {
           
            this.Show();
            _soundplayer.Play();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            soundplayer = new SoundPlayer("Power_Down.wav");
            soundplayer.Play();

            //clean close with audio
            CancellationTokenSource ts = new CancellationTokenSource();
            Thread thread = new Thread(CancelToken);
            thread.Start(ts);

            Task t = Task.Run(() => {
                Task.Delay(1000).Wait();
            });
            try
            {
                bool result = t.Wait(1000, ts.Token);   
            }
            catch (OperationCanceledException r)
            {
                Thread.Sleep(1000);
                ts.Dispose();
                this.Close();
            }
            

        }
        private static void CancelToken(Object obj)
        {
            Thread.Sleep(150);
            Console.WriteLine("", Thread.CurrentThread.ManagedThreadId);
            if (obj is CancellationTokenSource source) source.Cancel();
        }

        private void IntroForm_Load(object sender, EventArgs e)
        {

        }

        private void IntroHeader_Click(object sender, EventArgs e)
        {
            
        }

        private void musicButton_CheckedChanged(object sender, EventArgs e)
        {
            
            if (musicButton.Checked)
            {
                _soundplayer.Play();
            }
            else
            {
                _soundplayer.Stop();
            }
        }

        private void play3Button_Click(object sender, EventArgs e)
        {
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            GameForm3 GameForm = new GameForm3();
            GameForm.FormClosed += new FormClosedEventHandler(GameForm_FormClosed);
            this.Hide();
            GameForm.Show();
        }

        private void play4Button_Click(object sender, EventArgs e)
        {
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            GameForm4 GameForm = new GameForm4();
            GameForm.FormClosed += new FormClosedEventHandler(GameForm_FormClosed);
            this.Hide();
            GameForm.Show();

        }

        private void play5Button_Click(object sender, EventArgs e)
        {
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            GameForm GameForm = new GameForm();
            GameForm.FormClosed += new FormClosedEventHandler(GameForm_FormClosed);
            this.Hide();
            GameForm.Show();
        }

        private void play6Button_Click(object sender, EventArgs e)
        {
            soundplayer = new SoundPlayer("buttonTap.wav");
            soundplayer.Play();
            GameForm6 GameForm = new GameForm6();
            GameForm.FormClosed += new FormClosedEventHandler(GameForm_FormClosed);
            this.Hide();
            GameForm.Show();
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            soundplayer = new SoundPlayer("buttonTap.wav");
            StartButton.Visible = true;
            ExitButton.Visible = true;
            play3Button.Visible = false;
            play4Button.Visible = false;
            play5Button.Visible = false;
            play6Button.Visible = false;
            backButton.Visible = false;
        }
    }
}
