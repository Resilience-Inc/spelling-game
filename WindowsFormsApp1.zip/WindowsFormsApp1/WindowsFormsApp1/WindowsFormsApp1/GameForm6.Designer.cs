﻿namespace WindowsFormsApp1
{
    partial class GameForm6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameForm6));
            this.hintButton = new System.Windows.Forms.Button();
            this.awardTextBox = new System.Windows.Forms.TextBox();
            this.awardImageBox = new System.Windows.Forms.PictureBox();
            this.hintBox = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.placeBox5 = new System.Windows.Forms.PictureBox();
            this.placeBox4 = new System.Windows.Forms.PictureBox();
            this.placeBox3 = new System.Windows.Forms.PictureBox();
            this.placeBox2 = new System.Windows.Forms.PictureBox();
            this.placeBox1 = new System.Windows.Forms.PictureBox();
            this.Exit_Game_Button = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.NextButton = new System.Windows.Forms.Button();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.StartButton = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.placeBox6 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.awardImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // hintButton
            // 
            this.hintButton.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.hintButton.BackColor = System.Drawing.Color.Transparent;
            this.hintButton.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.button_1;
            this.hintButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hintButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.hintButton.FlatAppearance.BorderColor = System.Drawing.Color.Wheat;
            this.hintButton.FlatAppearance.BorderSize = 0;
            this.hintButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.hintButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.hintButton.Location = new System.Drawing.Point(251, 3);
            this.hintButton.Name = "hintButton";
            this.hintButton.Size = new System.Drawing.Size(75, 61);
            this.hintButton.TabIndex = 56;
            this.hintButton.Text = "Hint";
            this.hintButton.UseVisualStyleBackColor = false;
            this.hintButton.Click += new System.EventHandler(this.hintButton_Click);
            // 
            // awardTextBox
            // 
            this.awardTextBox.BackColor = System.Drawing.Color.Sienna;
            this.awardTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.awardTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.awardTextBox.ForeColor = System.Drawing.Color.Gold;
            this.awardTextBox.Location = new System.Drawing.Point(392, 418);
            this.awardTextBox.MaximumSize = new System.Drawing.Size(30, 40);
            this.awardTextBox.MaxLength = 3;
            this.awardTextBox.MinimumSize = new System.Drawing.Size(30, 20);
            this.awardTextBox.Name = "awardTextBox";
            this.awardTextBox.Size = new System.Drawing.Size(30, 19);
            this.awardTextBox.TabIndex = 55;
            this.awardTextBox.Text = "0";
            this.awardTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // awardImageBox
            // 
            this.awardImageBox.BackColor = System.Drawing.Color.Transparent;
            this.awardImageBox.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.gold_medal;
            this.awardImageBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.awardImageBox.Location = new System.Drawing.Point(357, 412);
            this.awardImageBox.Name = "awardImageBox";
            this.awardImageBox.Size = new System.Drawing.Size(29, 36);
            this.awardImageBox.TabIndex = 54;
            this.awardImageBox.TabStop = false;
            // 
            // hintBox
            // 
            this.hintBox.Location = new System.Drawing.Point(357, 386);
            this.hintBox.MinimumSize = new System.Drawing.Size(312, 20);
            this.hintBox.Name = "hintBox";
            this.hintBox.Size = new System.Drawing.Size(312, 20);
            this.hintBox.TabIndex = 42;
            this.hintBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.hintBox.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.ErrorImage = null;
            this.pictureBox4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.InitialImage")));
            this.pictureBox4.Location = new System.Drawing.Point(510, 109);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(84, 84);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 53;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox4_MouseDown);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.ErrorImage = null;
            this.pictureBox5.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.InitialImage")));
            this.pictureBox5.Location = new System.Drawing.Point(600, 84);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(84, 84);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox5.TabIndex = 52;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox5_MouseDown);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.ErrorImage = null;
            this.pictureBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.InitialImage")));
            this.pictureBox3.Location = new System.Drawing.Point(420, 84);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(84, 84);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 51;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseDown);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.ErrorImage = null;
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(330, 109);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(84, 84);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 50;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseDown);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(240, 84);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(84, 84);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            // 
            // placeBox5
            // 
            this.placeBox5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.placeBox5.ErrorImage = null;
            this.placeBox5.InitialImage = ((System.Drawing.Image)(resources.GetObject("placeBox5.InitialImage")));
            this.placeBox5.Location = new System.Drawing.Point(600, 228);
            this.placeBox5.Name = "placeBox5";
            this.placeBox5.Size = new System.Drawing.Size(84, 84);
            this.placeBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.placeBox5.TabIndex = 48;
            this.placeBox5.TabStop = false;
            this.placeBox5.DragDrop += new System.Windows.Forms.DragEventHandler(this.placeBox5_DragDrop);
            this.placeBox5.DragEnter += new System.Windows.Forms.DragEventHandler(this.placeBox5_DragEnter);
            // 
            // placeBox4
            // 
            this.placeBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.placeBox4.ErrorImage = null;
            this.placeBox4.InitialImage = ((System.Drawing.Image)(resources.GetObject("placeBox4.InitialImage")));
            this.placeBox4.Location = new System.Drawing.Point(510, 228);
            this.placeBox4.Name = "placeBox4";
            this.placeBox4.Size = new System.Drawing.Size(84, 84);
            this.placeBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.placeBox4.TabIndex = 47;
            this.placeBox4.TabStop = false;
            this.placeBox4.DragDrop += new System.Windows.Forms.DragEventHandler(this.placeBox4_DragDrop);
            this.placeBox4.DragEnter += new System.Windows.Forms.DragEventHandler(this.placeBox4_DragEnter);
            // 
            // placeBox3
            // 
            this.placeBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.placeBox3.ErrorImage = null;
            this.placeBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("placeBox3.InitialImage")));
            this.placeBox3.Location = new System.Drawing.Point(420, 228);
            this.placeBox3.Name = "placeBox3";
            this.placeBox3.Size = new System.Drawing.Size(84, 84);
            this.placeBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.placeBox3.TabIndex = 46;
            this.placeBox3.TabStop = false;
            this.placeBox3.DragDrop += new System.Windows.Forms.DragEventHandler(this.placeBox3_DragDrop);
            this.placeBox3.DragEnter += new System.Windows.Forms.DragEventHandler(this.placeBox3_DragEnter);
            // 
            // placeBox2
            // 
            this.placeBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.placeBox2.ErrorImage = null;
            this.placeBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("placeBox2.InitialImage")));
            this.placeBox2.Location = new System.Drawing.Point(330, 228);
            this.placeBox2.Name = "placeBox2";
            this.placeBox2.Size = new System.Drawing.Size(84, 84);
            this.placeBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.placeBox2.TabIndex = 45;
            this.placeBox2.TabStop = false;
            this.placeBox2.DragDrop += new System.Windows.Forms.DragEventHandler(this.placeBox2_DragDrop);
            this.placeBox2.DragEnter += new System.Windows.Forms.DragEventHandler(this.placeBox2_DragEnter);
            // 
            // placeBox1
            // 
            this.placeBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.placeBox1.ErrorImage = null;
            this.placeBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("placeBox1.InitialImage")));
            this.placeBox1.Location = new System.Drawing.Point(240, 228);
            this.placeBox1.Name = "placeBox1";
            this.placeBox1.Size = new System.Drawing.Size(84, 84);
            this.placeBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.placeBox1.TabIndex = 44;
            this.placeBox1.TabStop = false;
            this.placeBox1.DragDrop += new System.Windows.Forms.DragEventHandler(this.placeBox1_DragDrop);
            this.placeBox1.DragEnter += new System.Windows.Forms.DragEventHandler(this.placeBox1_DragEnter);
            // 
            // Exit_Game_Button
            // 
            this.Exit_Game_Button.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Exit_Game_Button.BackColor = System.Drawing.Color.Transparent;
            this.Exit_Game_Button.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.button_1;
            this.Exit_Game_Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Exit_Game_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Exit_Game_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Exit_Game_Button.Location = new System.Drawing.Point(251, 365);
            this.Exit_Game_Button.Name = "Exit_Game_Button";
            this.Exit_Game_Button.Size = new System.Drawing.Size(100, 69);
            this.Exit_Game_Button.TabIndex = 43;
            this.Exit_Game_Button.Text = "Stop";
            this.Exit_Game_Button.UseVisualStyleBackColor = false;
            this.Exit_Game_Button.Click += new System.EventHandler(this.Exit_Game_Button_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(357, 360);
            this.textBox1.MinimumSize = new System.Drawing.Size(312, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(312, 20);
            this.textBox1.TabIndex = 41;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NextButton
            // 
            this.NextButton.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.NextButton.BackColor = System.Drawing.Color.Transparent;
            this.NextButton.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.button_1;
            this.NextButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.NextButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NextButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.NextButton.Location = new System.Drawing.Point(675, 365);
            this.NextButton.Margin = new System.Windows.Forms.Padding(0);
            this.NextButton.Name = "NextButton";
            this.NextButton.Size = new System.Drawing.Size(100, 69);
            this.NextButton.TabIndex = 40;
            this.NextButton.Text = "Next";
            this.NextButton.UseVisualStyleBackColor = false;
            this.NextButton.Click += new System.EventHandler(this.NextButton_Click);
            // 
            // SubmitButton
            // 
            this.SubmitButton.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.SubmitButton.BackColor = System.Drawing.Color.Transparent;
            this.SubmitButton.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.button_1;
            this.SubmitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SubmitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SubmitButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SubmitButton.Location = new System.Drawing.Point(700, 3);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(75, 61);
            this.SubmitButton.TabIndex = 39;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.SubmitButton.UseVisualStyleBackColor = false;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // StartButton
            // 
            this.StartButton.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.StartButton.BackColor = System.Drawing.Color.Transparent;
            this.StartButton.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.button_1;
            this.StartButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.StartButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.StartButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.StartButton.Location = new System.Drawing.Point(26, 3);
            this.StartButton.Name = "StartButton";
            this.StartButton.Size = new System.Drawing.Size(75, 61);
            this.StartButton.TabIndex = 38;
            this.StartButton.Text = "Start";
            this.StartButton.UseVisualStyleBackColor = false;
            this.StartButton.Click += new System.EventHandler(this.StartButton_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox6.ErrorImage = null;
            this.pictureBox6.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.InitialImage")));
            this.pictureBox6.Location = new System.Drawing.Point(690, 109);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(84, 84);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox6.TabIndex = 57;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox6_MouseDown);
            // 
            // placeBox6
            // 
            this.placeBox6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.placeBox6.ErrorImage = null;
            this.placeBox6.InitialImage = ((System.Drawing.Image)(resources.GetObject("placeBox6.InitialImage")));
            this.placeBox6.Location = new System.Drawing.Point(690, 228);
            this.placeBox6.Name = "placeBox6";
            this.placeBox6.Size = new System.Drawing.Size(84, 84);
            this.placeBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.placeBox6.TabIndex = 58;
            this.placeBox6.TabStop = false;
            this.placeBox6.DragDrop += new System.Windows.Forms.DragEventHandler(this.placeBox6_DragDrop);
            this.placeBox6.DragEnter += new System.Windows.Forms.DragEventHandler(this.placeBox6_DragEnter);
            // 
            // GameForm6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.classroom_3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.placeBox6);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.hintButton);
            this.Controls.Add(this.awardTextBox);
            this.Controls.Add(this.awardImageBox);
            this.Controls.Add(this.hintBox);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.placeBox5);
            this.Controls.Add(this.placeBox4);
            this.Controls.Add(this.placeBox3);
            this.Controls.Add(this.placeBox2);
            this.Controls.Add(this.placeBox1);
            this.Controls.Add(this.Exit_Game_Button);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.NextButton);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.StartButton);
            this.Name = "GameForm6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GameForm6";
            this.Load += new System.EventHandler(this.GameForm6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.awardImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.placeBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button hintButton;
        private System.Windows.Forms.TextBox awardTextBox;
        private System.Windows.Forms.PictureBox awardImageBox;
        private System.Windows.Forms.TextBox hintBox;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox placeBox5;
        private System.Windows.Forms.PictureBox placeBox4;
        private System.Windows.Forms.PictureBox placeBox3;
        private System.Windows.Forms.PictureBox placeBox2;
        private System.Windows.Forms.PictureBox placeBox1;
        private System.Windows.Forms.Button Exit_Game_Button;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button NextButton;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.Button StartButton;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox placeBox6;
    }
}