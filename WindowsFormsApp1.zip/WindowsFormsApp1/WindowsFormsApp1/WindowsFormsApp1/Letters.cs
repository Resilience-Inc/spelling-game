﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1
{
    public class Letters : GameForm3
    {

        char LetterName;

        // use letterName to reference the value
        // of the charater taken from word conacatenation
        // to the value of Letter Objects and images
        private int LetterID;
        public Bitmap LetterImage;
        //public System.Windows.Forms.Cursor LetterCursor;


        public Letters()
        {

        }

        public static Letters List(char ID)
        {
            // group and return letter object based on letterID
            Letters letterReturned = new Letters();

           

            switch (ID)
            {
                case 'A':
                    {
                        if(ID == 'A')
                        {
                            letterReturned = LetterA;
                            return letterReturned;
                        }

                        break;
                    }
                case 'B':
                    {
                        if(ID == 'B')
                        {
                            letterReturned = LetterB;
                            return letterReturned;
                        }
                        
                        break;
                    }
                case 'C':
                    {
                        if (ID == 'C')
                        {
                            letterReturned = LetterC;
                            return letterReturned;
                        }
                        break;
                    }
                case 'D':
                    {
                        if (ID == 'D')
                        {
                            letterReturned = LetterD;
                            return letterReturned;
                        }
                        break;
                    }
                case 'E':
                    {
                        if (ID == 'E')
                        {
                            letterReturned = LetterE;
                            return letterReturned;
                        }
                        break;
                    }
                case 'F':
                    {
                        if (ID == 'F')
                        {
                            letterReturned = LetterF;
                            return letterReturned;
                        }
                        break;
                    }
                case 'G':
                    {
                        if (ID == 'G')
                        {
                            letterReturned = LetterG;
                            return letterReturned;
                        }
                        break;
                    }
                case 'H':
                    {
                        if (ID == 'H')
                        {
                            letterReturned = LetterH;
                            return letterReturned;
                        }
                        break;
                    }
                case 'I':
                    {
                        if (ID == 'I')
                        {
                            letterReturned = LetterI;
                            return letterReturned;
                        }
                        break;
                    }
                case 'J':
                    {
                        if (ID == 'J')
                        {
                            letterReturned = LetterJ;
                            return letterReturned;
                        }
                        break;
                    }
                case 'K':
                    {
                        if (ID == 'K')
                        {
                            letterReturned = LetterK;
                            return letterReturned;
                        }
                        break;
                    }
                case 'L':
                    {
                        if (ID == 'L')
                        {
                            letterReturned = LetterL;
                            return letterReturned;
                        }
                        break;
                    }
                case 'M':
                    {
                        if (ID == 'M')
                        {
                            letterReturned = LetterM;
                            return letterReturned;
                        }
                        break;
                    }
                case 'N':
                    {
                        if (ID == 'N')
                        {
                            letterReturned = LetterN;
                            return letterReturned;
                        }
                        break;
                    }
                case 'O':
                    {
                        if (ID == 'O')
                        {
                            letterReturned = LetterO;
                            return letterReturned;
                        }
                        break;
                    }
                case 'P':
                    {
                        if (ID == 'P')
                        {
                            letterReturned = LetterP;
                            return letterReturned;
                        }
                        break;
                    }
                case 'Q':
                    {
                        if (ID == 'Q')
                        {
                            letterReturned = LetterQ;
                            return letterReturned;
                        }
                        break;
                    }
                case 'R':
                    {
                        if (ID == 'R')
                        {
                            letterReturned = LetterR;
                            return letterReturned;
                        }
                        break;
                    }
                case 'S':
                    {
                        if (ID == 'S')
                        {
                            letterReturned = LetterS;
                            return letterReturned;
                        }
                        break;
                    }
                case 'T':
                    {
                        if (ID == 'T')
                        {
                            letterReturned = LetterT;
                            return letterReturned;
                        }
                        break;
                    }
                case 'U':
                    {
                        if (ID == 'U')
                        {
                            letterReturned = LetterU;
                            return letterReturned;
                        }
                        break;
                    }
                case 'V':
                    {
                        if (ID == 'V')
                        {
                            letterReturned = LetterV;
                            return letterReturned;
                        }
                        break;
                    }
                case 'W':
                    {
                        if (ID == 'W')
                        {
                            letterReturned = LetterW;
                            return letterReturned;
                        }
                        break;
                    }
                case 'X':
                    {
                        if (ID == 'X')
                        {
                            letterReturned = LetterX;
                            return letterReturned;
                        }
                        break;
                    }
                case 'Y':
                    {
                        if (ID == 'Y')
                        {
                            letterReturned = LetterY;
                            return letterReturned;
                        }
                        break;
                    }
                case 'Z':
                    {
                        if (ID == 'Z')
                        {
                            letterReturned = LetterZ;
                            return letterReturned;
                        }
                        break;
                    }

            }

           
            return letterReturned;
        }


        // define each letter object
        static readonly Letters LetterA = new Letters
        {
            LetterName = 'A', // reference the concat word letters value
            LetterID = 1,
            LetterImage = Resources.letter_a
        };


        static readonly Letters LetterB = new Letters()
        {
            LetterName = 'B',
            LetterID = 2,
            LetterImage = Resources.letter_b
        };

        static readonly Letters LetterC = new Letters()
        {
            LetterName = 'C',
            LetterID = 3,
            LetterImage = Resources.letter_c

        };

        static readonly Letters LetterD = new Letters()
        {
            LetterName = 'D',
            LetterID = 4,
            LetterImage = Resources.letter_d
        };

        static readonly Letters LetterE = new Letters()
        {
            LetterName = 'E',
            LetterID = 5,
            LetterImage = Resources.letter_e
        };

        static readonly Letters LetterF = new Letters
        {
            LetterName = 'F',
            LetterID = 6,
            LetterImage = Resources.letter_f
        };

        static readonly Letters LetterG = new Letters()
        {
            LetterName = 'G',
            LetterID = 7,
            LetterImage = Resources.letter_g
        };

        static readonly Letters LetterH = new Letters()
        {
            LetterName = 'H',
            LetterID = 8,
            LetterImage = Resources.letter_h
        };

        static readonly Letters LetterI = new Letters()
        {
            LetterName = 'I',
            LetterID = 9,
            LetterImage = Resources.letter_i
        };

        static readonly Letters LetterJ = new Letters()
        {
            LetterName = 'J',
            LetterID = 10,
            LetterImage = Resources.letter_j
        };

        static readonly Letters LetterK = new Letters
        {
            LetterName = 'K',
            LetterID = 11,
            LetterImage = Resources.letter_k
        };

        static readonly Letters LetterL = new Letters()
        {
            LetterName = 'L',
            LetterID = 12,
            LetterImage = Resources.letter_l
        };

        static readonly Letters LetterM = new Letters()
        {
            LetterName = 'M',
            LetterID = 13,
            LetterImage = Resources.letter_m
        };

        static readonly Letters LetterN = new Letters()
        {
            LetterName = 'N',
            LetterID = 14,
            LetterImage = Resources.letter_n
        };

        static readonly Letters LetterO = new Letters()
        {
            LetterName = 'O',
            LetterID = 15,
            LetterImage = Resources.letter_o
        };

        static readonly Letters LetterP = new Letters
        {
            LetterName = 'P',
            LetterID = 16,
            LetterImage = Resources.letter_p
        };

        static readonly Letters LetterQ = new Letters()
        {
            LetterName = 'Q',
            LetterID = 17,
            LetterImage = Resources.letter_q
        };

        static readonly Letters LetterR = new Letters()
        {
            LetterName = 'R',
            LetterID = 18,
            LetterImage = Resources.letter_r
        };

        static readonly Letters LetterS = new Letters()
        {
            LetterName = 'S',
            LetterID = 19,
            LetterImage = Resources.letter_s
        };

        static readonly Letters LetterT = new Letters()
        {
            LetterName = 'T',
            LetterID = 20,
            LetterImage = Resources.letter_t
        };

        static readonly Letters LetterU = new Letters()
        {
            LetterName = 'U',
            LetterID = 21,
            LetterImage = Resources.letter_u
        };

        static readonly Letters LetterV = new Letters()
        {
            LetterName = 'V',
            LetterID = 22,
            LetterImage = Resources.letter_v
        };

        static readonly Letters LetterW = new Letters
        {
            LetterName = 'W',
            LetterID = 23,
            LetterImage = Resources.letter_w
        };

        static readonly Letters LetterX = new Letters()
        {
            LetterName = 'X',
            LetterID = 24,
            LetterImage = Resources.letter_x
        };

        static readonly Letters LetterY = new Letters()
        {
            LetterName = 'Y',
            LetterID = 25,
            LetterImage = Resources.letter_y
        };

        static readonly Letters LetterZ = new Letters()
        {
            LetterName = 'Z',
            LetterID = 26,
            LetterImage = Resources.letter_z
            //LetterCursor = Resources.letter_z_drag
        };

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Letters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Name = "Letters";
            this.Load += new System.EventHandler(this.Letters_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void Letters_Load(object sender, EventArgs e)
        {

        }
    }
}