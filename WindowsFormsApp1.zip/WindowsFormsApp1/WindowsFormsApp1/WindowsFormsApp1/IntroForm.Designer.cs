﻿namespace WindowsFormsApp1
{
    partial class IntroForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IntroForm));
            this.IntroHeader = new System.Windows.Forms.Label();
            this.StartButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.musicButton = new System.Windows.Forms.CheckBox();
            this.play3Button = new System.Windows.Forms.Button();
            this.play4Button = new System.Windows.Forms.Button();
            this.play5Button = new System.Windows.Forms.Button();
            this.play6Button = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // IntroHeader
            // 
            this.IntroHeader.AutoSize = true;
            this.IntroHeader.BackColor = System.Drawing.Color.Transparent;
            this.IntroHeader.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.IntroHeader.Font = new System.Drawing.Font("Bernard MT Condensed", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IntroHeader.ForeColor = System.Drawing.Color.Gold;
            this.IntroHeader.Location = new System.Drawing.Point(95, 149);
            this.IntroHeader.MaximumSize = new System.Drawing.Size(300, 100);
            this.IntroHeader.MinimumSize = new System.Drawing.Size(300, 60);
            this.IntroHeader.Name = "IntroHeader";
            this.IntroHeader.Size = new System.Drawing.Size(300, 96);
            this.IntroHeader.TabIndex = 0;
            this.IntroHeader.Text = "Welcome to Spelling Pro";
            this.IntroHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.IntroHeader.UseCompatibleTextRendering = true;
            this.IntroHeader.Click += new System.EventHandler(this.IntroHeader_Click);
            // 
            // StartButton
            // 
            this.StartButton.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.StartButton.BackColor = System.Drawing.Color.Transparent;
            this.StartButton.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.button_1;
            this.StartButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.StartButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.StartButton.Location = new System.Drawing.Point(195, 248);
            this.StartButton.MaximumSize = new System.Drawing.Size(100, 80);
            this.StartButton.MinimumSize = new System.Drawing.Size(100, 80);
            this.StartButton.Name = "StartButton";
            this.StartButton.Size = new System.Drawing.Size(100, 80);
            this.StartButton.TabIndex = 2;
            this.StartButton.Text = "Play";
            this.StartButton.UseVisualStyleBackColor = false;
            this.StartButton.Click += new System.EventHandler(this.StartButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.ExitButton.BackColor = System.Drawing.Color.Transparent;
            this.ExitButton.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.button_1;
            this.ExitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ExitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ExitButton.Location = new System.Drawing.Point(195, 334);
            this.ExitButton.MaximumSize = new System.Drawing.Size(100, 80);
            this.ExitButton.MinimumSize = new System.Drawing.Size(100, 80);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(100, 80);
            this.ExitButton.TabIndex = 2;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // musicButton
            // 
            this.musicButton.Appearance = System.Windows.Forms.Appearance.Button;
            this.musicButton.AutoSize = true;
            this.musicButton.BackColor = System.Drawing.Color.Transparent;
            this.musicButton.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.button_1;
            this.musicButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.musicButton.Checked = true;
            this.musicButton.CheckState = System.Windows.Forms.CheckState.Checked;
            this.musicButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.musicButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.musicButton.Location = new System.Drawing.Point(109, 248);
            this.musicButton.Name = "musicButton";
            this.musicButton.Size = new System.Drawing.Size(80, 23);
            this.musicButton.TabIndex = 3;
            this.musicButton.Text = "music On/Off";
            this.musicButton.UseVisualStyleBackColor = false;
            this.musicButton.CheckedChanged += new System.EventHandler(this.musicButton_CheckedChanged);
            // 
            // play3Button
            // 
            this.play3Button.BackColor = System.Drawing.Color.Transparent;
            this.play3Button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("play3Button.BackgroundImage")));
            this.play3Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.play3Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.play3Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.play3Button.Location = new System.Drawing.Point(195, 248);
            this.play3Button.Name = "play3Button";
            this.play3Button.Size = new System.Drawing.Size(97, 37);
            this.play3Button.TabIndex = 4;
            this.play3Button.Text = "3 Letters";
            this.play3Button.UseVisualStyleBackColor = false;
            this.play3Button.Visible = false;
            this.play3Button.Click += new System.EventHandler(this.play3Button_Click);
            // 
            // play4Button
            // 
            this.play4Button.BackColor = System.Drawing.Color.Transparent;
            this.play4Button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("play4Button.BackgroundImage")));
            this.play4Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.play4Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.play4Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.play4Button.Location = new System.Drawing.Point(195, 291);
            this.play4Button.Name = "play4Button";
            this.play4Button.Size = new System.Drawing.Size(97, 37);
            this.play4Button.TabIndex = 5;
            this.play4Button.Text = "4 Letters";
            this.play4Button.UseVisualStyleBackColor = false;
            this.play4Button.Visible = false;
            this.play4Button.Click += new System.EventHandler(this.play4Button_Click);
            // 
            // play5Button
            // 
            this.play5Button.BackColor = System.Drawing.Color.Transparent;
            this.play5Button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("play5Button.BackgroundImage")));
            this.play5Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.play5Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.play5Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.play5Button.Location = new System.Drawing.Point(195, 334);
            this.play5Button.Name = "play5Button";
            this.play5Button.Size = new System.Drawing.Size(97, 37);
            this.play5Button.TabIndex = 6;
            this.play5Button.Text = "5 Letters";
            this.play5Button.UseVisualStyleBackColor = false;
            this.play5Button.Visible = false;
            this.play5Button.Click += new System.EventHandler(this.play5Button_Click);
            // 
            // play6Button
            // 
            this.play6Button.AccessibleRole = System.Windows.Forms.AccessibleRole.PageTabList;
            this.play6Button.BackColor = System.Drawing.Color.Transparent;
            this.play6Button.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("play6Button.BackgroundImage")));
            this.play6Button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.play6Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.play6Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.play6Button.Location = new System.Drawing.Point(195, 377);
            this.play6Button.Name = "play6Button";
            this.play6Button.Size = new System.Drawing.Size(97, 37);
            this.play6Button.TabIndex = 7;
            this.play6Button.Text = "6 Letters";
            this.play6Button.UseVisualStyleBackColor = false;
            this.play6Button.Visible = false;
            this.play6Button.Click += new System.EventHandler(this.play6Button_Click);
            // 
            // backButton
            // 
            this.backButton.BackColor = System.Drawing.Color.Transparent;
            this.backButton.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.button_1;
            this.backButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.backButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.backButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.backButton.Location = new System.Drawing.Point(109, 377);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(80, 37);
            this.backButton.TabIndex = 8;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = false;
            this.backButton.Visible = false;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // IntroForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.set_of_cute_school_children_design_vector;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(477, 637);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.play6Button);
            this.Controls.Add(this.play5Button);
            this.Controls.Add(this.play4Button);
            this.Controls.Add(this.play3Button);
            this.Controls.Add(this.musicButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.StartButton);
            this.Controls.Add(this.IntroHeader);
            this.Name = "IntroForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Spelling Pro";
            this.Load += new System.EventHandler(this.IntroForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label IntroHeader;
        private System.Windows.Forms.Button StartButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.CheckBox musicButton;
        private System.Windows.Forms.Button play3Button;
        private System.Windows.Forms.Button play4Button;
        private System.Windows.Forms.Button play5Button;
        private System.Windows.Forms.Button play6Button;
        private System.Windows.Forms.Button backButton;
    }
}